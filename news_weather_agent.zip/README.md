# Beginner News and Weather Agent

This is my first OpenAI Agents SDK project.

## What it does

The agent has two tools:

1. Weather tool - gets current weather using Open-Meteo.
2. News tool - gets recent headlines using Google News RSS.

## Files

- main.py - main Python program
- .env - stores the OpenAI API key
- .gitignore - prevents the API key from being uploaded to GitHub
- requirements.txt - Python packages

## Run

Install packages:

```bash
pip install -r requirements.txt
```

Add your API key to `.env`:

```text
OPENAI_API_KEY=your_api_key_here
```

Then run:

```bash
python main.py
```

Try questions such as:

- What is the weather in Faisalabad?
- Give me the latest news about artificial intelligence.
