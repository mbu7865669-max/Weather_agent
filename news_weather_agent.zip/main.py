import os
import requests
from dotenv import load_dotenv
from agents import Agent, Runner, function_tool

load_dotenv()


@function_tool
def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    url = "https://geocoding-api.open-meteo.com/v1/search"
    response = requests.get(url, params={"name": city, "count": 1})
    data = response.json()

    if "results" not in data:
        return "City not found."

    location = data["results"][0]
    latitude = location["latitude"]
    longitude = location["longitude"]

    weather_url = "https://api.open-meteo.com/v1/forecast"
    weather_response = requests.get(
        weather_url,
        params={
            "latitude": latitude,
            "longitude": longitude,
            "current": "temperature_2m,wind_speed_10m",
        },
    )

    weather = weather_response.json()["current"]

    return (
        f"Weather in {location['name']}: "
        f"{weather['temperature_2m']}°C, "
        f"wind speed {weather['wind_speed_10m']} km/h."
    )


@function_tool
def get_news(topic: str) -> str:
    """Get a few recent news headlines about a topic."""
    url = "https://news.google.com/rss/search"
    response = requests.get(
        url,
        params={"q": topic, "hl": "en-US", "gl": "US", "ceid": "US:en"},
    )

    import xml.etree.ElementTree as ET

    root = ET.fromstring(response.text)
    headlines = []

    for item in root.findall(".//item")[:5]:
        title = item.find("title")
        if title is not None:
            headlines.append(title.text)

    if not headlines:
        return "No news found."

    return "\n".join(f"- {headline}" for headline in headlines)


agent = Agent(
    name="News and Weather Agent",
    instructions=(
        "You are a simple helpful assistant. "
        "Use the weather tool when the user asks about weather. "
        "Use the news tool when the user asks for news. "
        "Answer in simple language."
    ),
    tools=[get_weather, get_news],
)


question = input("Ask me something: ")

result = Runner.run_sync(agent, question)

print("\nAgent:")
print(result.final_output)
